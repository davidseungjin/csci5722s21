% Names: Alec Bell, David Lee
% Course #: CSCI 5722
% Assignment #: 1
% Instructor: Fleming

function [outImg] = invert_NL(inImg)
% Inverts the image by subtracting each RGB value for each pixel by 255.

outImg = 255 - inImg;

end

